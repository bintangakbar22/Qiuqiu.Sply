<?php
$conn = mysqli_connect("localhost","root","","react_qiuqiusply");

$encodedData = file_get_contents('php://input');  // take data from react native fetch API
$decodedData = json_decode($encodedData, true);
// script cek koneksi   
if (!$conn) {
    die("Koneksi Tidak Berhasil: " . mysqli_connect_error());
}
