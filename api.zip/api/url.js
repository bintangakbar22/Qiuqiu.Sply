// export const URLQ = 'https://qiuqiusplyy.000webhostapp.com/api/';
export const URLQ = 'http://192.168.0.118/RNQiuqiusply/api/';
export const ImageUser = URLQ +'images/user/';
export const ImageBanner = URLQ +'images/banner/';
export const ImageProduct = URLQ +'images/product/';
